/**
 *  Programa que muestra el uso de las clases
 *  Punto2D y OperacionesConPuntos2D
 *
 *  Actividad a realizar:
 *  1.- Pedir los datos en enorno gráfico
 *  2.- Probar los métodos de OperacionesConPuntos2D
 *
 *   @version 22/Sep/22
 */

package test.Metricas1;
import test.Metricas1.Punto2D;
import test.Metricas1.OperacionesConPuntos2D;
import javax.swing.JOptionPane;

public class UsaOperacionesConPuntos2D {

    public static void main(String[]args){
        Punto2D a = new Punto2D(3,2);
        Punto2D b = new Punto2D(5,4);
        double norma = OperacionesConPuntos2D.norma(a);
        double dAB = OperacionesConPuntos2D.metricaEuclidiana(a,b);
        double dtaxiAB=OperacionesConPuntos2D.metricaTaxista(a,b);
        double ProductoAB=OperacionesConPuntos2D.dotProduct(a,b);
        double areaAB=OperacionesConPuntos2D.area(a,b);
        
        
        JOptionPane.showMessageDialog(null,"El punto a es:"+ a);
        JOptionPane.showMessageDialog(null,"El punto b es:"+ b);

        System.out.println("La norma de " + a + " es : " + norma);
        System.out.println("La distancia del punto" + a +"al punto"+ b +" es: " + dAB);
        System.out.println("La distancia Manhattan del punto" + a +"al punto"+ b +" es: " + dtaxiAB);
        System.out.println("El producto Escalar del punto" + a +"al punto"+ b +" es: " + ProductoAB);
        System.out.println("El area del circulo es: " + areaAB );
        
        JOptionPane.showMessageDialog(null, "La norma de " + a + " es : \n" + norma);
        JOptionPane.showMessageDialog(null,"La distancia del punto "+ a + "al punto" + b+ " es: \n"  + dAB);
        JOptionPane.showMessageDialog(null,"La distancia Manhattan del punto" + a +"al punto"+ b +" es: " + dtaxiAB);
        JOptionPane.showMessageDialog(null,"El Producto Escalar punto" + a +"al punto"+ b +" es: " + ProductoAB);
        JOptionPane.showMessageDialog(null,"El area del circulo es: " + areaAB );
        
    }
}
